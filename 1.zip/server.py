import asyncio
import os
import struct
import pandas as pd
async def linux(data):
    if data.replace(" ","")=="help":
        return '''
Команды:
list - выводит процессы и сохраняет их в формате xml.\n
SIGINT id - Прерывает процесс и выполняет очистку перед завершением. Вместо id нужно указать id процесса.\n
SIGHUP id - Перезагружает процесс. Вместо id нужно указать id процесса.\n
SIGQUIT id - Используется для завершения процесса и создания дампа памяти. Вместо id нужно указать id процесса.\n
SIGSTOP id - Останавливает (приостанавливает) процесс. Вместо id нужно указать id процесса.\n
SIGCONT id - Возобновляет выполнение приостановленного процесса. Вместо id нужно указать id процесса.\n
SIGTERM id - Завершения проценна корректно. Вместо id нужно указать id процесса.\n
SIGKILL id - Принудительное завершение процесса. Вместо id нужно указать id процесса.\n
               '''.encode('utf-8')
    elif(data.replace(" ","")=="list"):
        stream = os.popen('ps aux')
        output = stream.read()
        print(output)
    elif "SIGINT" in data or "sigint" in data:
        data=data.repalce(" ",'')
        id=data.replace("SIGINT","")
        id=data.replace("sigint","")
        try:
            os.system(f'kill -SIGINT {id}')
            return "Успешно".encode('utf-8')
        except:
            return "Ошибка синтаксиса, не верно указан id".encode('utf-8')

    elif "SIGHUP" in data or "sighup" in data:
        data=data.repalce(" ",'')
        id=data.replace("SIGHUP","")
        id=data.replace("sighup","")
        try:
            os.system(f'kill -SIGHUP {id}')
            return "Успешно".encode('utf-8')
        except:
            return "Ошибка синтаксиса, не верно указан id".encode('utf-8')

    elif "SIGQUIT" in data or "sigquit" in data:
        data=data.repalce(" ",'')
        id=data.replace("SIGQUIT","")
        id=data.replace("sigquit","")
        try:
            os.system(f'kill -SIGQUIT {id}')
            return "Успешно".encode('utf-8')
        except:
            return "Ошибка синтаксиса, не верно указан id".encode('utf-8')
    elif "SIGSTOP" in data or "sigstop" in data:
        data=data.repalce(" ",'')
        id=data.replace("SIGSTOP","")
        id=data.replace("sigstop","")
        try:
            os.system(f'kill -SIGSTOP {id}')
            return "Успешно".encode('utf-8')
        except:
            return "Ошибка синтаксиса, не верно указан id".encode('utf-8')
    elif "SIGCONT" in data or "sigcont" in data:
        data=data.repalce(" ",'')
        id=data.replace("SIGCONT","")
        id=data.replace("sigcont","")
        try:
            os.system(f'kill -SIGCONT {id}')
            return "Успешно".encode('utf-8')
        except:
            return "Ошибка синтаксиса, не верно указан id".encode('utf-8')
    elif "SIGTERM" in data or "sigterm" in data:
        data=data.repalce(" ",'')
        id=data.replace("SIGTERM","")
        id=data.replace("sigterm","")
        try:
            os.system(f'kill -SIGTERM {id}')
            return "Успешно".encode('utf-8')
        except:
            return "Ошибка синтаксиса, не верно указан id".encode('utf-8')
    elif "SIGKILL" in data or "sigkill" in data:
        data=data.repalce(" ",'')
        id=data.replace("SIGKILL","")
        id=data.replace("sigkill","")
        try:
            os.system(f'kill -SIGKILL {id}')
            return "Успешно".encode('utf-8')
        except:
            return "Ошибка синтаксиса, не верно указан id".encode('utf-8')
    else:
        return "Ошибка синтаксиса, введите команду help для подсказки".encode('utf-8')
async def windows(data):
    os.system('chcp 65001 > nul 2>&1')
    if(data.replace(" ","")=="list"):
        stream = os.popen('tasklist')
        output = stream.read().replace("В\xa0", "").split("\n")[3:]
        to_exel=[i.split() for i in output]
        process=[i[0] for i in to_exel[:-1]]
        pid=[i[1] for i in to_exel[:-1]]
        typ=[i[2] for i in to_exel[:-1]]
        user=[i[3] for i in to_exel[:-1]]
        potok=[i[4] for i in to_exel[:-1]]
        kol=[i[5] for i in to_exel[:-1]]
        data = {
            'Процесс': process,
            'PID': pid,
            'Тип': typ,
            'Пользователь':user,
            'Поток':potok,
            'К':kol
        }
        df = pd.DataFrame(data)
        xml_data = df.to_xml(root_name='processes', row_name='process', index=False, encoding='utf-8')
        xml_bytes = xml_data.encode('utf-8')
        header="xml".encode('utf-8')
        packet = header+ xml_bytes + b'\0'
        return packet
    elif(data.replace(" ","")=="help"):
        header="com".encode('utf-8')
        return header+'''
Команды:
list - выводит процессы и сохраняет их в формате xml.
SIGTERM pid - Завершения проценна корректно. Вместо id нужно указать pid процесса.
SIGKILL pid - Принудительное завершение процесса. Вместо id нужно указать pid процесса.
               '''.encode('utf-8')+ b'\0'
    elif "SIGTERM" in data or "sigterm" in data:
        data=data.repalce(" ",'')
        id=data.replace("SIGTERM","")
        id=data.replace("sigterm","")
        header="com".encode('utf-8')
        try:
            os.system(f'taskkill /PID {id} /T /F')
            return header+"Успешно".encode('utf-8')+ b'\0'
        except:
            return header+"Ошибка синтаксиса, не верно указан pid".encode('utf-8')+ b'\0'
    elif "SIGKILL" in data or "sigkill" in data:
        data=data.repalce(" ",'')
        id=data.replace("SIGKILL","")
        id=data.replace("sigkill","")
        header="com".encode('utf-8')
        try:
            os.system(f'taskkill /F /PID {id}')
            return header+"Успешно".encode('utf-8')+ b'\0'
        except:
            return header+"Ошибка синтаксиса, не верно указан pid".encode('utf-8')+ b'\0'
    else:
        header="com".encode('utf-8')
        return header+"Ошибка синтаксиса, введите команду help для подсказки".encode('utf-8')+ b'\0'

async def client(reader, writer):
    addr = writer.get_extra_info('peername')
    print(f"Подключение от {addr}")
    while (data := (await reader.read(100)).decode()) != "close":
        if data!="":
            if os.name == 'posix':
                answer=await linux(data.replace(" ",""))
                writer.write(answer.encode())
                await writer.drain()
            else:
                answer=await windows(data.replace(" ",""))
                writer.write(answer)
                await writer.drain()
    writer.write("Закрытие соединения")
    writer.close()
    await writer.wait_closed()
    

async def main():
    server = await asyncio.start_server(client, 'localhost', 8000)
    async with server:
        await server.serve_forever()

asyncio.run(main())